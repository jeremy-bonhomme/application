import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.html',
})
export class HeaderC implements OnInit {

  public constructor() { }

  public ngOnInit(): void { }

}
