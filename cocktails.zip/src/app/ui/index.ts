import { Type } from '@angular/core';

export interface UiIcon {
  after?: boolean;
  class?: string;
  spin?: boolean;
  symbol: string;
}