import { Component } from '@angular/core';

@Component( {
  selector: 'app-cocktails',
  templateUrl: 'default.html',
} )
export class CocktailsC { }
