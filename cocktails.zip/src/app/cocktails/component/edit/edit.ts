import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Params } from '@angular/router';

import { CocktailS } from 'app/cocktails/service';
import { Cocktail } from 'app/cocktails/store/model';

@Component( {
  selector: 'app-cocktail-edit',
  templateUrl: 'edit.html',
} )
export class CocktailsEditC implements OnInit {

  public add: string;
  public cocktailForm: FormGroup;
  public cocktail: Cocktail;
  public cocktails: Cocktail[];
  public edit: boolean;
  public forbiddenWordsMessage: string;
  public isSubmitted: boolean;
  public message: string;

  public forbiddenWords: Array<any> = [
    'test',
    'chien',
    'rat',
  ];

  public constructor( protected fb: FormBuilder, protected _cocktailS: CocktailS, protected _ar: ActivatedRoute ) { }

  public ngOnInit(): void {
    this._ar.params.subscribe( (params: Params ) => {
      if ( params.i ) {
        this.edit = true;
        this._cocktailS.getCocktail( params.i ).subscribe( ( cocktail: Cocktail ) => {
          this.cocktail = cocktail;
          this.initForm( params.i, this.cocktail );
        } );
      } else {
        this.edit = false;
        this.initForm(  params.i, { desc: '', img: '', ingredients: [ { name: '', quantity: '' } ], name: '' } );
      }
    } );
    this._cocktailS.cocktails.subscribe( ( cocktails: Cocktail[] ) => {
      this.cocktails = cocktails;
    } );
    this.forbiddenWordsMessage = `Le mot que vous souhaitez utiliser est interdit !`;
  }

  public addIngredient(): string {
    const formEl: FormArray = this.cocktailForm.get( 'ingredients' ) as FormArray;
    if ( formEl.length < 8 ) {
      formEl.push( this.fb.group( {
        name: [ '' ],
        quantity: [ '' ],
      } ) );
    } else if ( formEl.length === 8 ) {
      return ( this.message = 'Vous ne pouvez ajouter que 8 ingrédients maximum');
    }
  }

  public createCocktail(): void {
    if ( this.edit ) {
      this._cocktailS.editCocktail( this.cocktailForm.value );
      this.isSubmitted = true;
      this.add = 'Votre cocktail a bien été mis à jour';
    } else {
      this._cocktailS.addCocktail( this.cocktailForm.value );
      this.isSubmitted = true;
      this.add = 'Votre cocktail a bien été ajouté';
      this.cocktailForm.reset();
    }
  }

  public get formData(): {} {
    const formEl: FormArray = this.cocktailForm.get( 'ingredients' ) as FormArray;
    return formEl;
  }

  public initForm( i: number, cocktail: Cocktail = { desc: '', img: '', ingredients: [ { name: '', quantity: '' } ], name: '' } ): void {
    this.cocktailForm = this.fb.group( {
      desc: [ cocktail.desc, [ Validators.required, this.validatorValue.bind( this ) ] ],
      img: [ cocktail.img, [ Validators.required, this.validatorValue.bind( this ) ] ],
      ingredients: this.fb.array( this.test() ),
      name: [ cocktail.name, [ Validators.required, this.validatorValue.bind( this ) ] ],
    } );
  }

  public test() {
    return this.cocktail.ingredients
    .map( ( ingredient ) => this.fb.group( {
      name: [ ingredient.name, Validators.minLength( 6 ) ],
      quantity: [ ingredient.quantity, Validators.minLength( 6 ) ],
    } ) );
  }

  public get desc( ): {} { return this.cocktailForm.get( 'desc'); }
  public get img( ): {} { return this.cocktailForm.get( 'img' ); }
  public get name( ): {} { return this.cocktailForm.get( 'name' ); }

  public removeIngredient( i: number ): string {
    const formEl: FormArray =  this.cocktailForm.get( 'ingredients' ) as FormArray;
    formEl.removeAt( i );
    return ( this.message = '');
  }

  public validatorValue( formControl: FormControl ): any {
    let i: number = 0;
    while ( i < this.forbiddenWords.length ) {
      if ( formControl.value.toLowerCase().includes( this.forbiddenWords[ i ] ) ) {
        return { isInvalid: true };
      } else {
        i++;
      }
    }
  }
}
