import { Component } from '@angular/core';

@Component( {
  selector: 'app-panier',
  templateUrl: 'panier.html',
})
export class PanierC {

}
