export class Ingredient {
  public constructor(
    public name: string,
    public quantity: string,
  )  { }
}
